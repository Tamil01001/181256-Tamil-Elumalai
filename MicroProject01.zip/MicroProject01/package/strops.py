### Character Map ###

# Input
s = input("Enter the word: ")

# Process
def charactermap(s):
    for i, ch in enumerate(s):
        chmap = f"index {i}: {ch}"

# Output
        print("output:",chmap)

charactermap(s)
    

### Count Words ###

# Input
s = input("Enter a sentance:")

# Process
def countwords(s):
    return len(s.split())

# Output
print("Number of words are:", countwords(s))


### Get Permutations ###

import itertools

# Input
s = input("Give your input:")

# Process
def getpermutations(s):
    return [''.join(p) for p in itertools.permutations(s)]


# Output
print("Permutations of the given are:", getpermutations(s))


### Make Title ###

# Input
s = input("Enter a sentance:")

# Process
def maketitle(s):
    return s.title()

# Output
print("Result is:", maketitle(s))


### Normalize Spaces ###

# Input
s = input("Enter some words with various spaces between:")


# Process
def normalizespaces(s):
    return ' '.join(s.split())

# Output
print("Normalized space between words:", normalizespaces(s))

### Remove Punctuations ###

import string

# Input
s = input("Enter a sentance with punctuations:")


# Process
def removepunctuation(s):
    return s.translate(str.maketrans("", "" , string.punctuation))

# Output
print("Scentance cleaned from punctuation:",removepunctuation(s))


### Reverse Words ###

# Input
s = input("Enter the sentance:")

# Process
def reversewords(s):
    words = s.split()
    return ' '.join(reversed(words))

# Output
print("Reversed sentance:",reversewords(s))

### Transform ###

# Input
s = input("Enter the word:")

# Process
def transform(s):
    return s[::-1].swapcase()

# Output
print("Transformed sentance:",transform(s))

### Get Span ###

# Input
s = input("Enter the main string: ")
ss = input("Enter the substring to find: ")

# Process
def getspan(s, ss):
    index = s.find(ss)  

    if index == -1:  
        return None
    else:
        return (index, index + len(ss) - 1)

# Output
result = getspan(s, ss)
if result:
    print(f"The substring '{ss}' is found from index {result[0]} to {result[1]}.")
else:
    print(f"The substring '{ss}' is not found.")
