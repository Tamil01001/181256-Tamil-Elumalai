from setuptools import setup

setup(
    name='package',
    version='0.1',
    description='Micro Project package',
    url='#',
    author='tamil',
    author_email='tamil@ust.in',
    license='NA',
    packages=['package'],
    zip_safe=False
)